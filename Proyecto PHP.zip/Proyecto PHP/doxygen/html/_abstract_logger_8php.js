var _abstract_logger_8php =
[
    [ "AbstractLogger", "class_psr_1_1_log_1_1_abstract_logger.html", null ]
];