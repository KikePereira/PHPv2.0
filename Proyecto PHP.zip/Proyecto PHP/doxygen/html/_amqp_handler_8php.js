var _amqp_handler_8php =
[
    [ "AmqpHandler", "class_monolog_1_1_handler_1_1_amqp_handler.html", "class_monolog_1_1_handler_1_1_amqp_handler" ]
];