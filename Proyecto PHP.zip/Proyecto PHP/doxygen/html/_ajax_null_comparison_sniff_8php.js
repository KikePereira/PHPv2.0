var _ajax_null_comparison_sniff_8php =
[
    [ "AjaxNullComparisonSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_my_source_1_1_sniffs_1_1_p_h_p_1_1_ajax_null_comparison_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_my_source_1_1_sniffs_1_1_p_h_p_1_1_ajax_null_comparison_sniff" ]
];