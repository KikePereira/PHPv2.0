var _backfill_numeric_separator_test_8php =
[
    [ "BackfillNumericSeparatorTest", "class_p_h_p___code_sniffer_1_1_tests_1_1_core_1_1_tokenizer_1_1_backfill_numeric_separator_test.html", "class_p_h_p___code_sniffer_1_1_tests_1_1_core_1_1_tokenizer_1_1_backfill_numeric_separator_test" ]
];