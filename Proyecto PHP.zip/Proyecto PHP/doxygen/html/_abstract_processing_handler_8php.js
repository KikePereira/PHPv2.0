var _abstract_processing_handler_8php =
[
    [ "AbstractProcessingHandler", "class_monolog_1_1_handler_1_1_abstract_processing_handler.html", "class_monolog_1_1_handler_1_1_abstract_processing_handler" ]
];