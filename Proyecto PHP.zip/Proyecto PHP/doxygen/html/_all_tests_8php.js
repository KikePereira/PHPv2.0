var _all_tests_8php =
[
    [ "PHP_CodeSniffer_AllTests", "class_p_h_p___code_sniffer_1_1_tests_1_1_p_h_p___code_sniffer___all_tests.html", null ],
    [ "$phpunit7", "_all_tests_8php.html#a36ab2f321c646f947d1603485c93207f", null ],
    [ "else", "_all_tests_8php.html#a2b2bbef8a8731a9ca9d5143bc54d9c38", null ]
];