var _array_indent_sniff_8php =
[
    [ "ArrayIndentSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_sniffs_1_1_arrays_1_1_array_indent_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_sniffs_1_1_arrays_1_1_array_indent_sniff" ]
];