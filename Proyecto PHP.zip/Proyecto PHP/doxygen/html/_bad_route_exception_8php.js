var _bad_route_exception_8php =
[
    [ "BadRouteException", "class_fast_route_1_1_bad_route_exception.html", null ]
];