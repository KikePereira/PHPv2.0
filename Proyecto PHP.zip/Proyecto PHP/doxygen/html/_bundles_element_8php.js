var _bundles_element_8php =
[
    [ "BundlesElement", "class_phar_io_1_1_manifest_1_1_bundles_element.html", "class_phar_io_1_1_manifest_1_1_bundles_element" ]
];