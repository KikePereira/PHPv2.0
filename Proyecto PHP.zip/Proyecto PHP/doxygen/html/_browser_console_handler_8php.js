var _browser_console_handler_8php =
[
    [ "BrowserConsoleHandler", "class_monolog_1_1_handler_1_1_browser_console_handler.html", "class_monolog_1_1_handler_1_1_browser_console_handler" ]
];