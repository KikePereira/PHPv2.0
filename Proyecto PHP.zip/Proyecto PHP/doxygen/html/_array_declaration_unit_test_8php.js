var _array_declaration_unit_test_8php =
[
    [ "ArrayDeclarationUnitTest", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_tests_1_1_arrays_1_1_array_declaration_unit_test.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_tests_1_1_arrays_1_1_array_declaration_unit_test" ]
];