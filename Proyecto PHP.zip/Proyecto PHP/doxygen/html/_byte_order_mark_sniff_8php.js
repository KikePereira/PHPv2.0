var _byte_order_mark_sniff_8php =
[
    [ "ByteOrderMarkSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_sniffs_1_1_files_1_1_byte_order_mark_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_sniffs_1_1_files_1_1_byte_order_mark_sniff" ]
];