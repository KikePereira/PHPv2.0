var _boolean_operator_placement_unit_test_8inc =
[
    [ "do", "_boolean_operator_placement_unit_test_8inc.html#ab7cc452b1dc300e21c5a47d1202d5b87", null ],
    [ "match", "_boolean_operator_placement_unit_test_8inc.html#a3aa24593e2c1dba089b2a77994098315", null ]
];