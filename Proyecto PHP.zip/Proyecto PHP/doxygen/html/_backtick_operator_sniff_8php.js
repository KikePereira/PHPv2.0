var _backtick_operator_sniff_8php =
[
    [ "BacktickOperatorSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_sniffs_1_1_p_h_p_1_1_backtick_operator_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_sniffs_1_1_p_h_p_1_1_backtick_operator_sniff" ]
];