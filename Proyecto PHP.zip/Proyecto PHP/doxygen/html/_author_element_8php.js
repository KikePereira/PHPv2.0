var _author_element_8php =
[
    [ "AuthorElement", "class_phar_io_1_1_manifest_1_1_author_element.html", "class_phar_io_1_1_manifest_1_1_author_element" ]
];