var _builder_2_trait_use_adaptation_8php =
[
    [ "TraitUseAdaptation", "class_php_parser_1_1_builder_1_1_trait_use_adaptation.html", "class_php_parser_1_1_builder_1_1_trait_use_adaptation" ]
];