var _author_collection_iterator_8php =
[
    [ "AuthorCollectionIterator", "class_phar_io_1_1_manifest_1_1_author_collection_iterator.html", "class_phar_io_1_1_manifest_1_1_author_collection_iterator" ]
];