var _assign_name_expression_8php =
[
    [ "AssignNameExpression", "class_twig_1_1_node_1_1_expression_1_1_assign_name_expression.html", "class_twig_1_1_node_1_1_expression_1_1_assign_name_expression" ]
];