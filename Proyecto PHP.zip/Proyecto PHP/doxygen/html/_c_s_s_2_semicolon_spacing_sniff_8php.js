var _c_s_s_2_semicolon_spacing_sniff_8php =
[
    [ "SemicolonSpacingSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_sniffs_1_1_c_s_s_1_1_semicolon_spacing_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_sniffs_1_1_c_s_s_1_1_semicolon_spacing_sniff" ]
];