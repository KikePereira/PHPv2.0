var _activation_strategy_interface_8php =
[
    [ "ActivationStrategyInterface", "interface_monolog_1_1_handler_1_1_fingers_crossed_1_1_activation_strategy_interface.html", "interface_monolog_1_1_handler_1_1_fingers_crossed_1_1_activation_strategy_interface" ]
];