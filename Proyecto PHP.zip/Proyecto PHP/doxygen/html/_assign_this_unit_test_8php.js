var _assign_this_unit_test_8php =
[
    [ "AssignThisUnitTest", "class_p_h_p___code_sniffer_1_1_standards_1_1_my_source_1_1_tests_1_1_objects_1_1_assign_this_unit_test.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_my_source_1_1_tests_1_1_objects_1_1_assign_this_unit_test" ]
];