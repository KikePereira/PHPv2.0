var _abstract_syslog_handler_8php =
[
    [ "AbstractSyslogHandler", "class_monolog_1_1_handler_1_1_abstract_syslog_handler.html", "class_monolog_1_1_handler_1_1_abstract_syslog_handler" ]
];