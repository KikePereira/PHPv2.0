var _abstract_array_sniff_test_8php =
[
    [ "AbstractArraySniffTest", "class_p_h_p___code_sniffer_1_1_tests_1_1_core_1_1_sniffs_1_1_abstract_array_sniff_test.html", "class_p_h_p___code_sniffer_1_1_tests_1_1_core_1_1_sniffs_1_1_abstract_array_sniff_test" ]
];