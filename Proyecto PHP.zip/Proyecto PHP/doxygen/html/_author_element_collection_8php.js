var _author_element_collection_8php =
[
    [ "AuthorElementCollection", "class_phar_io_1_1_manifest_1_1_author_element_collection.html", "class_phar_io_1_1_manifest_1_1_author_element_collection" ]
];