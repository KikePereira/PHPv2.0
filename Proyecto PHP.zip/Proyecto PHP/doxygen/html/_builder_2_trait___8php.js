var _builder_2_trait___8php =
[
    [ "Trait_", "class_php_parser_1_1_builder_1_1_trait__.html", "class_php_parser_1_1_builder_1_1_trait__" ]
];