var _author_collection_8php =
[
    [ "AuthorCollection", "class_phar_io_1_1_manifest_1_1_author_collection.html", "class_phar_io_1_1_manifest_1_1_author_collection" ]
];