var _assign_op_2_coalesce_8php =
[
    [ "Coalesce", "class_php_parser_1_1_node_1_1_expr_1_1_assign_op_1_1_coalesce.html", "class_php_parser_1_1_node_1_1_expr_1_1_assign_op_1_1_coalesce" ]
];