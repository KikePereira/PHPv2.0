var _attribute_emulator_8php =
[
    [ "AttributeEmulator", "class_php_parser_1_1_lexer_1_1_token_emulator_1_1_attribute_emulator.html", "class_php_parser_1_1_lexer_1_1_token_emulator_1_1_attribute_emulator" ]
];