var _arguments_wildcard_8php =
[
    [ "ArgumentsWildcard", "class_prophecy_1_1_argument_1_1_arguments_wildcard.html", "class_prophecy_1_1_argument_1_1_arguments_wildcard" ]
];