var _api_8php =
[
    [ "__phpunit_getInvocationHandler", "_api_8php.html#a0bca3e749046dd4a6d35892f2e93802d", null ],
    [ "__phpunit_hasMatchers", "_api_8php.html#a99b92781783b2b1a06ded1e667fec951", null ],
    [ "__phpunit_setOriginalObject", "_api_8php.html#aa4d0cc04ee56a89094ff907a0102202d", null ],
    [ "__phpunit_setReturnValueGeneration", "_api_8php.html#abc27772bf64e268ee8d0b81f1a63555d", null ],
    [ "__phpunit_verify", "_api_8php.html#a6822ed59dd10562d47700fa843e17ee5", null ],
    [ "expects", "_api_8php.html#a46b334abfbf0b5b0036f185cca3a287e", null ],
    [ "Api", "_api_8php.html#ac0d4967de4aa62d7c96449d138da6c59", null ]
];