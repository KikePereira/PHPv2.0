var _bad_method_call_exception_8php =
[
    [ "BadMethodCallException", "class_p_h_p_unit_1_1_framework_1_1_mock_object_1_1_bad_method_call_exception.html", null ]
];