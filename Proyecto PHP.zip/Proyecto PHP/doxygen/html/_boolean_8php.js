var _boolean_8php =
[
    [ "Boolean", "classphp_documentor_1_1_reflection_1_1_types_1_1_boolean.html", "classphp_documentor_1_1_reflection_1_1_types_1_1_boolean" ]
];