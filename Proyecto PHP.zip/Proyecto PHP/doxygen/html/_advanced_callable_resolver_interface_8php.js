var _advanced_callable_resolver_interface_8php =
[
    [ "AdvancedCallableResolverInterface", "interface_slim_1_1_interfaces_1_1_advanced_callable_resolver_interface.html", "interface_slim_1_1_interfaces_1_1_advanced_callable_resolver_interface" ]
];