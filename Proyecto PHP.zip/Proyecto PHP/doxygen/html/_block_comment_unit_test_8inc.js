var _block_comment_unit_test_8inc =
[
    [ "MyClass", "class_my_class.html", "class_my_class" ],
    [ "Foo", "class_foo.html", "class_foo" ],
    [ "TabTest", "class_tab_test.html", "class_tab_test" ],
    [ "func", "_block_comment_unit_test_8inc.html#a17c6e659a89c18fa9459ec5341063fb8", null ],
    [ "$code", "_block_comment_unit_test_8inc.html#a7949acdaecc70b9f035c12a7069db132", null ],
    [ "$y", "_block_comment_unit_test_8inc.html#aeaf6a729fb346d42f29f3335dd81995d", null ],
    [ "MyTrait", "_block_comment_unit_test_8inc.html#a0eef4f5ccb0ea3c3ad3b4ae9fee3f348", null ]
];