var _buffer_handler_8php =
[
    [ "BufferHandler", "class_monolog_1_1_handler_1_1_buffer_handler.html", "class_monolog_1_1_handler_1_1_buffer_handler" ]
];