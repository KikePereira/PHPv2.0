var _abstract_extension_8php =
[
    [ "AbstractExtension", "class_twig_1_1_extension_1_1_abstract_extension.html", "class_twig_1_1_extension_1_1_abstract_extension" ]
];