var _abstract_scope_sniff_8php =
[
    [ "AbstractScopeSniff", "class_p_h_p___code_sniffer_1_1_sniffs_1_1_abstract_scope_sniff.html", "class_p_h_p___code_sniffer_1_1_sniffs_1_1_abstract_scope_sniff" ]
];