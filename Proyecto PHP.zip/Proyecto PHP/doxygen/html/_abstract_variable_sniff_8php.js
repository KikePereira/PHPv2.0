var _abstract_variable_sniff_8php =
[
    [ "AbstractVariableSniff", "class_p_h_p___code_sniffer_1_1_sniffs_1_1_abstract_variable_sniff.html", "class_p_h_p___code_sniffer_1_1_sniffs_1_1_abstract_variable_sniff" ]
];