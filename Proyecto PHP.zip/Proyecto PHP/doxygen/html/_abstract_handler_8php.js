var _abstract_handler_8php =
[
    [ "AbstractHandler", "class_monolog_1_1_handler_1_1_abstract_handler.html", "class_monolog_1_1_handler_1_1_abstract_handler" ]
];