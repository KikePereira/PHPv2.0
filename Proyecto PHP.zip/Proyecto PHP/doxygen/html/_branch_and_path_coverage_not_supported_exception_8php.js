var _branch_and_path_coverage_not_supported_exception_8php =
[
    [ "BranchAndPathCoverageNotSupportedException", "class_sebastian_bergmann_1_1_code_coverage_1_1_branch_and_path_coverage_not_supported_exception.html", null ]
];