var _backtick_operator_unit_test_8php =
[
    [ "BacktickOperatorUnitTest", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_tests_1_1_p_h_p_1_1_backtick_operator_unit_test.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_generic_1_1_tests_1_1_p_h_p_1_1_backtick_operator_unit_test" ]
];