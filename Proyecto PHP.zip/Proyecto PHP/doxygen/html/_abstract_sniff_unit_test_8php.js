var _abstract_sniff_unit_test_8php =
[
    [ "AbstractSniffUnitTest", "class_p_h_p___code_sniffer_1_1_tests_1_1_standards_1_1_abstract_sniff_unit_test.html", "class_p_h_p___code_sniffer_1_1_tests_1_1_standards_1_1_abstract_sniff_unit_test" ]
];