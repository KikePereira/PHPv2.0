var _block_comment_sniff_8php =
[
    [ "BlockCommentSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_sniffs_1_1_commenting_1_1_block_comment_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_sniffs_1_1_commenting_1_1_block_comment_sniff" ]
];