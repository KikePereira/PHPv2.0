var _all_sniffs_8php =
[
    [ "AllSniffs", "class_p_h_p___code_sniffer_1_1_tests_1_1_standards_1_1_all_sniffs.html", null ]
];