var _array_declaration_sniff_8php =
[
    [ "ArrayDeclarationSniff", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_sniffs_1_1_arrays_1_1_array_declaration_sniff.html", "class_p_h_p___code_sniffer_1_1_standards_1_1_squiz_1_1_sniffs_1_1_arrays_1_1_array_declaration_sniff" ]
];